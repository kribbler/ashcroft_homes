<style type="text/css">
	#about{ float: right; width:250px; background: #ffc; border: 1px solid #333; padding: 5px; text-align: justify; }
	#about p, li, ol{ font-family:verdana; font-size:11px; }
	#about h3 {text-align:center;}
	.field_info {text-align:right;};
</style>
<?php echo "<div id='about'> 
	<h3>From the author</h3> 				
	<p>My name is <a href='http://onlinewebapplication.com/about-me/' target='_blank'>Pankaj Jha</a> and I've developed WP Lightbox 2. Nice to meet you! :)<p>
	<h3><a href='http://yepinol.com/lightbox-2-plugin-wordpress/' target='_blank'>Learn more about WP Lightbox 2  </a><h3>
	<h3> <a href='http://onlinewebapplication.com/wp-lighbox-2-support-forums/' target='_blank'>Forums/Discussion  </a></h3>
	<h3> <a href='http://yepinol.com/wp-lightbox-2-plugin-wordpress-demo/' target='_blank'>WP Lightbox 2 Demo  </a></h3>
	<h3> <a href='http://yepinol.com/wp-lightbox-2-faq/' target='_blank'>WP Lightbox 2 FAQ  </a></h3>
</div>"; 
?>
