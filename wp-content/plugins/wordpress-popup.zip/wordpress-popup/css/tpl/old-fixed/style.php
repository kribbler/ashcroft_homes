<?php
$info->name = __( 'Default Fixed', PO_LANG );
$info->deprecated = true;