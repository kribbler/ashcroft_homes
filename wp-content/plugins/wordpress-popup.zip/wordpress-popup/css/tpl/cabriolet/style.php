<?php
$info->name = __( 'Cabriolet', PO_LANG );
$info->pro = true;