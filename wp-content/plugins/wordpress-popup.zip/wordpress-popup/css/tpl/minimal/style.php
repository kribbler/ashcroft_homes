<?php
$info->name = __( 'Minimal', PO_LANG );
$info->pro = true;