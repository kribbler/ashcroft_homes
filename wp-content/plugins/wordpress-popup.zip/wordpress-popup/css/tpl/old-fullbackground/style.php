<?php
$info->name = __( 'Dark Background Fixed', PO_LANG );
$info->deprecated = true;