<?php
$info->name = __( 'Default', PO_LANG );
$info->deprecated = true;