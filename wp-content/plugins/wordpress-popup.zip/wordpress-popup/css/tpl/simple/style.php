<?php
$info->name = __( 'Simple', PO_LANG );
