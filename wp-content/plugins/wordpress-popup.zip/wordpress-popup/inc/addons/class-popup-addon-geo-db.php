<?php
/*
Addon Name:  Use Local Geo Database
Plugin URI:  http://premium.wpmudev.org/project/the-pop-over-plugin/
Description: Switches the geo checking from using an external API to using a local database
Author:      Barry (Incsub)
Author URI:  http://premium.wpmudev.org
Type:        Caching
Version:     1.0
*/

class IncPopupAddon_GeoDB {

	/**
	 * Initialize the addon.
	 *
	 * @since  4.6
	 */
	static public function init() {
	}
};
