<?php
/*
Name:        Screen Size
Plugin URI:  http://premium.wpmudev.org/project/the-pop-over-plugin/
Description: Adds a condition that can limit PopUps to certain screen sizes.
Author:      Ve (Incsub)
Author URI:  http://premium.wpmudev.org
Type:        Rule
Rules:       Depending on screen size
Limit:       pro
Version:     1.0

NOTE: DON'T RENAME THIS FILE!!
This filename is saved as metadata with each popup that uses these rules.
Renaming the file will DISABLE the rules, which is very bad!
*/