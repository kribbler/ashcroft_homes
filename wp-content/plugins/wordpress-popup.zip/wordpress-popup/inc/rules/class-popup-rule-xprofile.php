<?php
/*
Name:        XProfile Fields
Plugin URI:  http://premium.wpmudev.org/project/the-pop-over-plugin/
Description: BuddyPress: Examine values in the users extended profile.
Author:      Ve (Incsub)
Author URI:  http://premium.wpmudev.org
Type:        Rule
Rules:       On XProfile match, Not on XProfile match
Limit:       pro
Version:     1.0

NOTE: DON'T RENAME THIS FILE!!
This filename is saved as metadata with each popup that uses these rules.
Renaming the file will DISABLE the rules, which is very bad!
*/