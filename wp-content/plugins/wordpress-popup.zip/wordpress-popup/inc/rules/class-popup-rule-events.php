<?php
/*
Name:        JavaScript Events
Plugin URI:  http://premium.wpmudev.org/project/the-pop-over-plugin/
Description: New Behavior Options: Show PopUp when the mouse leaves the browser window or when the user clicks somewhere.
Author:      Ve (Incsub)
Author URI:  http://premium.wpmudev.org
Type:        Rule
Rules:
Limit:       pro
Version:     1.0

NOTE: DON'T RENAME THIS FILE!!
This filename is saved as metadata with each popup that uses these rules.
Renaming the file will DISABLE the rules, which is very bad!
*/